import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient, private router: Router) { }

  login(user: User) {
    this.http.post("http://localhost:5000/login", user).subscribe({
      next: (data: any) => {
        localStorage.setItem("token", data.token);
        console.log(data.token);
        this.router.navigate(['/profile'])
      }
    })
  }
  profile() {
    console.log("profile")
    let header = new HttpHeaders()
    .set("Authorization", `bearer ${localStorage.getItem('token')}`)
    this.http.post("http://localhost:5000/profile", {}, { headers: header }).subscribe({
      next: data => {console.log(data)},
      error:err=>{console.log("Token not found")}
    });
  }
}
