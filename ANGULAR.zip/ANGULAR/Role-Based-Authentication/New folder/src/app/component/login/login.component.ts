import { Token } from '@angular/compiler';
import { Component } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  user=new User();
  constructor(private service: UserService) { }
  doLogin() {
    this.service.login(this.user);
  }
}
