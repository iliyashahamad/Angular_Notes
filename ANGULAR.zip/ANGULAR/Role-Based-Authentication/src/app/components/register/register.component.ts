import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent 
{
  constructor(private service:AuthService,private router:Router,private toastr:ToastrService){}
  registerForm=new FormGroup({
    id:new FormControl('',Validators.compose([Validators.required,Validators.minLength(5)])),
    name:new FormControl('',Validators.required),
    //password:new FormControl('', Validators.compose([Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')])),
    //email:new FormControl('', Validators.compose([Validators.required, Validators.email])),
    password:new FormControl('',Validators.required),
    email:new FormControl('',Validators.required),
    gender:new FormControl('male'),
    role:new FormControl(''),
    isActive:new FormControl(false)
  });
  proceedRegistration(){
    this.service.registerUser(this.registerForm.value).subscribe({
      next:data=>{
        this.toastr.success("Please contact admin for enable","Ypou have been registered successfully");
        this,this.router.navigate(["/login"])
      },error:err=>this.toastr.success("OOPS!!!!!Something wnet wrong")
    }) ;   
  }
}
