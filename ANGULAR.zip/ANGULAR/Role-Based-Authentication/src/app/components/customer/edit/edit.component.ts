import { Component, Inject } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { Customer } from 'src/app/customer';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent {

  constructor(private service:CustomerService,@Inject(MAT_DIALOG_DATA) private data:any,
  private toastr:ToastrService,private dialog:MatDialogRef<EditComponent>){}
  editForm:FormGroup;
  customer:Customer;
  ngOnInit(): void {  
    this.editForm=new FormGroup({
      "id":new FormControl('',Validators.required),
      "firstname":new FormControl('',Validators.required),
      "lastname":new FormControl('',Validators.required),
      "address":new FormControl('',Validators.required),
      "phone":new FormControl('',Validators.required),
    });
    this.loadCustomer();
  }
  loadCustomer(){
    this.service.getCustomer(this.data.cid).subscribe(res=>{
      this.customer=res;
      this.editForm.controls["id"].setValue(this.customer.id);
      this.editForm.controls["firstname"].setValue(this.customer.firstname);
      this.editForm.controls["lastname"].setValue(this.customer.lastname);
      this.editForm.controls["address"].setValue(this.customer.address);
      this.editForm.controls["phone"].setValue(this.customer.phone);
    })
  }
  updateCustomer(){
    this.customer.id=this.editForm.controls["id"].value;
    this.customer.firstname=this.editForm.controls["firstname"].value;
    this.customer.lastname=this.editForm.controls["lastname"].value;
    this.customer.address=this.editForm.controls["address"].value;
    this.customer.phone=this.editForm.controls["phone"].value;
    console.log(this.customer);
    this.service.updateCustomer(this.customer).subscribe(res=>{
      this.toastr.success("Customer has been update successfully");
      this.dialog.close();
    });
  }
}
