import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent {

  constructor(private service:CustomerService,@Inject(MAT_DIALOG_DATA) public data:any,
  private toastr:ToastrService,private dialog:MatDialogRef<DeleteComponent>){}
  deleteCustomer(){
    this.service.deleteCustomer(this.data.cid).subscribe(res=>{
      this.toastr.success("Customer record has been deleted");
      this.dialog.close();
    })
  }
}
