import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { AuthService } from 'src/app/services/auth.service';
import { UpdatepopupComponent } from '../updatepopup/updatepopup.component';

@Component({
  selector: 'app-userlisting',
  templateUrl: './userlisting.component.html',
  styleUrls: ['./userlisting.component.css']
})
export class UserlistingComponent {

  constructor(private service:AuthService,private dialog:MatDialog){
    this.loadUserList();
  }
  @ViewChild(MatPaginator) paginator!:MatPaginator;
  @ViewChild(MatSort) sort!:MatSort;
  userList:any;
  dataSource:any;
  displayedColumns:string[]=["username","name","email","role","status","action"];
  loadUserList(){
    this.service.getAllUsers().subscribe(res=>{
      this.userList=res;
      this.dataSource=new MatTableDataSource(this.userList);
      this.dataSource.paginator=this.paginator;
      this.dataSource.sort=this.sort;
    })
  }
  updateUser(name:any){
    const popup=this.dialog.open(UpdatepopupComponent,{
      enterAnimationDuration:'1000ms',
      exitAnimationDuration:'500ms',
      width:'30%',
      data:{
        username:name
      }
    });
    popup.afterClosed().subscribe(res=>{
      this.loadUserList()
    })
  }
}
