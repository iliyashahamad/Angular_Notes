export class Customer {
    id:string;
    firstname:string;
    lastname:string;
    address:string;
    phone:string;
}
