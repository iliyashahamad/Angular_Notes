import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor() { }
  products=[
    {'pid':'AB123','name':'Laptop','description':'It is laptop.It is a computing device','brand':'Dell','qunatity':10,'price':67000,"photo":"laptop"},
    {'pid':'AB124','name':'Printer','description':'It is printer.It is used to print document','brand':'HP','qunatity':100,'price':6000,"photo":"printer"},
    {'pid':'AB125','name':'Mouse','description':'It is mouse.It is used to click','brand':'Logitech','qunatity':1000,'price':1800,"photo":"mouse"},
    {'pid':'AB126','name':'Keyboard','description':'It is keyboard.It is used to give input','brand':'Dell','qunatity':110,'price':1200,"photo":"keyboard"},
    {'pid':'AB127','name':'Desktop','description':'It is dekstop.It is used to perform computing','brand':'Acer','qunatity':10,'price':36000,"photo":"desktop"}
  ]
  getProducts(){
    return this.products;
  }
}
