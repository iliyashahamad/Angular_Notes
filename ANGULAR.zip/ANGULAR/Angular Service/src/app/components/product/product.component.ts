import { Component } from '@angular/core';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent 
{
  products;
  constructor(private service:ProductService)
  {
    this.products=service.getProducts();
  }
}
