import { getLocaleExtraDayPeriods } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent
{
  pid="";
  pname="";
  brand=""
  qty=0;
  price=0;
  file="";
  products;
  constructor(private route:ActivatedRoute,private service:ProductService)
  {
    this.products=service.getProducts();
    let x=route.snapshot.params["pid"];
    for(let i=0;i<this.products.length;i++)
    {
      if(x==this.products[i].pid)
      {
        this.pid=x;
        this.pname=this.products[i].name;
        this.brand=this.products[i].brand;
        this.qty=this.products[i].qunatity;
        this.price=this.products[i].price;
        this.file=this.products[i].photo;
        break;
      }
    }
  }
  
}
