import { Component } from '@angular/core';
import { Product } from 'src/app/product';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent 
{
  constructor(private service:ProductService){}
  pid:any;
  edit:boolean;
  found:boolean;
  msg:string="";
  product:Product;
  getRecord()
  {
    this.edit=true;
    this.service.searchProduct(this.pid).subscribe({
        next:data=>{this.product=data;this.found=true},
        error:er=>{this.found=false;this.msg="Product record does not exist"}
    })
  }
  updateRecord()
  {
    this.service.updateRecord(this.product).subscribe();
    alert("Record updated");
  }
}
