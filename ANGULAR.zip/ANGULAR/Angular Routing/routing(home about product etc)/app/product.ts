export class Product {
    pid:string
    name:string;
    description:string;
    brand:string;
    quantity:number
    price:number;
}
