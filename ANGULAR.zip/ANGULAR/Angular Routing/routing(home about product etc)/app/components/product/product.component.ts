import { Component } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent
{
  products=[
    {'pid':'AB123','name':'Laptop','description':'It is laptop.It is a computing device','brand':'Dell','qunatity':10,'price':67000},
    {'pid':'AB124','name':'Printer','description':'It is printer.It is used to print document','brand':'HP','qunatity':100,'price':6000},
    {'pid':'AB125','name':'Mouse','description':'It is mouse.It is used to click','brand':'Logitech','qunatity':1000,'price':1800},
    {'pid':'AB126','name':'Keyboard','description':'It is keyboard.It is used to give input','brand':'Dell','qunatity':110,'price':1200},
    {'pid':'AB127','name':'Desktop','description':'It is dekstop.It is used to perform computing','brand':'Acer','qunatity':10,'price':36000}
  ]
}
