import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from 'src/app/product';

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent
{
  id:string="";
  products:Product[]=[
    {'pid':'AB123','name':'Laptop','description':'It is laptop.It is a computing device','brand':'Dell','quantity':10,'price':67000},
    {'pid':'AB124','name':'Printer','description':'It is printer.It is used to print document','brand':'HP','quantity':100,'price':6000},
    {'pid':'AB125','name':'Mouse','description':'It is mouse.It is used to click','brand':'Logitech','quantity':1000,'price':1800},
    {'pid':'AB126','name':'Keyboard','description':'It is keyboard.It is used to give input','brand':'Dell','quantity':110,'price':1200},
    {'pid':'AB127','name':'Desktop','description':'It is dekstop.It is used to perform computing','brand':'Acer','quantity':10,'price':36000}
  ]
  product:Product[];
  pd:Product;
  constructor(private route:ActivatedRoute){
    this.id=this.route.snapshot.params['x'];
    this.product=this.products.filter(p=>p.pid==this.id);  
    this.pd=this.product[0];
  }
}
