var num1 = 90;
var num2 = 20;
var sum = num1 + num2;
console.log("Sum of " + num1 + " and " + num2 + " is " + sum);
