var x = 10;
//x=x+1;
++x;
console.log(x);
