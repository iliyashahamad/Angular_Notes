let x=10;
++x;
console.log(x);