var x = 10, y;
y = ++x - (x++ - x++);
console.log("x=" + x);
console.log("y=" + y);
