var str;
str = "Rehan Ahmad";
console.log("Hello " + str);
