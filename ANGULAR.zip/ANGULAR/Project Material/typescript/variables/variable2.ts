let num:number;
num=12345678983;
console.log(num);