let str:string;
str="Rehan Ahmad";
console.log("Hello "+str);