var num;
num = 12345678983;
console.log(num);
