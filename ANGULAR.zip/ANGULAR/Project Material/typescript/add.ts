let num1=90;
let num2=20;
let sum=num1+num2;
console.log("Sum of "+num1+" and "+num2+" is "+sum);