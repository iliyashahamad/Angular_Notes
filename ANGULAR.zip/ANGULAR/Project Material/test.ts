import { Employee } from "./employee";

class Test
{
    emp1=new Employee(101,"Rahul Mishra","Training",90000);
    disp()
    {
        //console.log("Welcome");
        this.emp1.showDetails();
    }
    show()
    {
        this.emp1.showDetails();
    }
}
let t=new Test();
t.disp();