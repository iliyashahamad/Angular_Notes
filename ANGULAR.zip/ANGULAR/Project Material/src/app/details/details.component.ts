import { Component } from '@angular/core';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent 
{
  products=
  [
    {"pid":101,"name":"Mouse","brand":"Logitech","price":1400,"quantity":0},
    {"pid":102,"name":"Laptop","brand":"Acer","price":78400,"quantity":20},
    {"pid":103,"name":"Printer","brand":"HP","price":5400,"quantity":0},
    {"pid":104,"name":"Keyboard","brand":"Dell","price":1900,"quantity":34},
    {"pid":105,"name":"Dekstop","brand":"HP","price":27400,"quantity":10},
  ];
}
