import { Employee } from "./employee";

class Test
{
    disp()
    {
        let emp1=new Employee(101,"Rahul Mishra","Training",90000);
        emp1.showDetails();
    }
    show()
    {
        emp1.showDetails();
    }
}
let t=new Test();
t.disp();