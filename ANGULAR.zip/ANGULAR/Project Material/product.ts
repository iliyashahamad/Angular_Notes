class Product
{
    //Defining properties of object
    pid:number;
    name:string;
    brand:string;
    price:number;
    //Defining constructor
    constructor(p1:number,p2:string,p3:string,p4:number)
    {
        this.pid=p1;
        this.name=p2;
        this.brand=p3;
        this.price=p4;
    }
    //Definging method inside class
    showDetails():void
    {
        console.log("Product id is:"+this.pid);
        console.log("Product name is:"+this.name);
        console.log("Product brand is:"+this.brand);
        console.log("Product price is:"+this.price);
    }
}
//Command to create objects from Product class
let ref1=new Product(101,"Mouse","Logitech",1500);
let ref2=new Product(102,"Lpatop","Logitech",1900);
ref2.showDetails();
ref1.showDetails();
