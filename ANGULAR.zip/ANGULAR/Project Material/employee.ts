export class Employee
{
    eid:number;
    name:string;
    department:string;
    salary:number;
    constructor(p1:number,p2:string,p3:string,p4:number)
    {
        this.eid=p1;
        this.name=p2;
        this.department=p3;
        this.salary=p4;
    }
    showDetails()
    {
        console.log("Employee id:"+this.eid);
        console.log("Employee name:"+this.name);
        console.log("Employee department:"+this.department);
        console.log("Employee salary:"+this.salary);
    }

}