import { Component } from '@angular/core';
import { Product } from 'src/app/product';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent 
{
  constructor(private service:ProductService){}
  pid:number;
  product:Product;
  search=false;
  found=false;
  searchRecord()
  {
    this.search=true;
    this.service.searchProduct(this.pid).subscribe(
      {
        next:data=>{this.product=data;this.found=true},
        error:er=>this.found=false
      }
    )
  }
}
