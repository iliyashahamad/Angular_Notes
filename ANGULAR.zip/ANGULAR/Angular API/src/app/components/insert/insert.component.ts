import { Component } from '@angular/core';
import { Product } from 'src/app/product';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent 
{

  constructor(private service:ProductService){}

  product=new Product();
  save()
  {
    this.service.saveRecord(this.product).subscribe();
    alert("Record saved")
  }
}
