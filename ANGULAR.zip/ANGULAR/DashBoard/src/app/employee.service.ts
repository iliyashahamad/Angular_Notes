import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './employee';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private client:HttpClient) { }
  baseUrl="http://localhost:3000/employee";

  saveRecord(employee:Employee):Observable<Employee>
  {
    return this.client.post<Employee>(this.baseUrl,employee);
  }
  getList():Observable<Employee[]>
  {
    return this.client.get<Employee[]>(this.baseUrl);
  }
  deleteRecord(eid:number):Observable<Employee>
  {
    return this.client.delete<Employee>(this.baseUrl+"/"+eid);
  }
  getRecord(eid:number):Observable<Employee>
  {
    return this.client.get<Employee>(this.baseUrl+"/"+eid);
  }
  updateRecord(employee:Employee):Observable<Employee>
  {
    return this.client.put<Employee>(this.baseUrl+"/"+employee.id,employee);
  }
}
