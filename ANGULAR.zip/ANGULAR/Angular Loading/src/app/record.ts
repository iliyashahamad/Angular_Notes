import { Dummy } from "./dummy";

export class Record 
{
    products:Dummy[];
    total:number;
    skip:number;
    limit:number;
}
