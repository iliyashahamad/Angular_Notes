import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Record } from './record';

@Injectable({
  providedIn: 'root'
})
export class DummyService {

  constructor(private client:HttpClient)  { }
  base:string="https://dummyjson.com/product";
  getData():Observable<Record>{
    return this.client.get<Record>(this.base);
  }
}
