import { Component, OnInit } from '@angular/core';
import { DummyService } from './dummy.service';
import { Dummy } from './dummy';
import { AA } from './aa';
import { AppModule } from './app.module';
import { environment } from 'src/environments/environments';
import { Record } from './record';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit
{
  constructor(private service:DummyService){}
  data:Dummy[];
  rc:Record;
  ngOnInit(): void 
  {
    this.service.getData().subscribe({
      next:data=>{this.rc=data;this.data=this.rc.products}
    })
  }
}
