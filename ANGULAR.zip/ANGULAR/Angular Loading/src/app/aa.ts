export class AA 
{
    static did:number=1;
}
