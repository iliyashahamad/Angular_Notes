export const environment = {
    did:1
  };