import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { InsertComponent } from './components/insert/insert.component';
import { ListComponent } from './components/list/list.component';
import { DeleteComponent } from './components/delete/delete.component';
import { EditComponent } from './components/edit/edit.component';
import { SearchComponent } from './components/search/search.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'save',component:InsertComponent},
  {path:'list',component:ListComponent},
  {path:'delete',component:DeleteComponent},
  {path:'edit',component:EditComponent},
  {path:'search',component:SearchComponent},
  {path:'',redirectTo:'home',pathMatch:'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
