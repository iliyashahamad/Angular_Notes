import { Component } from '@angular/core';
import { Employee } from 'src/app/employee';
import { EmployeeService } from 'src/app/employee.service';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent 
{
  constructor(private service:EmployeeService){}
  emp=new Employee();
  save()
  {
    this.service.saveEmployee(this.emp).subscribe({
      next:data=>alert("Employee record has been saved")
    });
  }
}
