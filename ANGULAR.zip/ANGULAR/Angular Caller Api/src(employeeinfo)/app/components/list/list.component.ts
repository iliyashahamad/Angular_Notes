import { Component,OnInit } from '@angular/core';
import { Employee } from 'src/app/employee';
import { EmployeeService } from 'src/app/employee.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit
{
  constructor(private service:EmployeeService){}
  empList:Employee[];
  ngOnInit(): void 
  {
    this.service.getEmployeeList().subscribe({
      next:data=>this.empList=data
    })
  }
}
