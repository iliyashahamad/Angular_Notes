import { Component } from '@angular/core';
import { Employee } from 'src/app/employee';
import { EmployeeService } from 'src/app/employee.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent 
{
  constructor(private service:EmployeeService){}
  emp:Employee;
  eid:number;
  search=false;
  found=false;
  msg="";
  emp1=new Employee();
  showRecord()
  {
    this.search=true;
    this.service.getEmployee(this.eid).subscribe({
      next:data=>{this.emp=data;this.found=true},
      error:err=>{this.found=false;this.msg="Record doest not exist"}
    })
  }
  updateRecord()
  {
    this.service.updateEmployee(this.emp,this.eid).subscribe({
      next:data=>{this.found=false;this.msg="Record has been updated"}
    })
  }
}
