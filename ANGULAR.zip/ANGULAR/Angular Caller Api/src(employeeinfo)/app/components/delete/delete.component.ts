import { Component } from '@angular/core';
import { Employee } from 'src/app/employee';
import { EmployeeService } from 'src/app/employee.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent 
{
  constructor(private service:EmployeeService){}
  emp:Employee;
  eid:number;
  search=false;
  found=false;
  msg="";
  showRecord()
  {
    this.search=true;
    this.service.getEmployee(this.eid).subscribe({
      next:data=>{this.emp=data;this.found=true},
      error:err=>{this.found=false;this.msg="Record doest not exist"}
    })
  }
  deleteRecord()
  {
    this.service.deleteEmployee(this.eid).subscribe({
      next:data=>{this.found=false;this.msg="Record has been deleted"}
    })
  }
}
