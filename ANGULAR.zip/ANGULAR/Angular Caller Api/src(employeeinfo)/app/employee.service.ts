import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './employee';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService 
{

  constructor(private client:HttpClient) { }
  baseUrl="http://localhost:3000/employee";

  saveEmployee(employee:Employee):Observable<Employee>
  {
    return this.client.post<Employee>(this.baseUrl,employee);
  }
  getEmployeeList():Observable<Employee[]>
  {
    return this.client.get<Employee[]>(this.baseUrl);
  }
  getEmployee(eid:number):Observable<Employee>
  {
    return this.client.get<Employee>(this.baseUrl+"/"+eid);
  }
  deleteEmployee(eid:number):Observable<Employee>
  {
    return this.client.delete<Employee>(this.baseUrl+"/"+eid);
  }
  updateEmployee(employee:Employee,eid:number):Observable<Employee>
  {
    return this.client.put<Employee>(this.baseUrl+"/"+eid,employee);
  }
}
